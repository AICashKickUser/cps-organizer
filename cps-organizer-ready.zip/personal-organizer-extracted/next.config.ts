import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  /* Static export for GitHub Pages deployment at /cps-organizer/ */
  basePath: "/cps-organizer",
  assetPrefix: "/cps-organizer/",
  images: {
    unoptimized: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
